public class Relogio {
	// atributos
	private int hora;
	private int minuto;
	private int segundo;
	
	// construtores
	public Relogio() {}
	public Relogio (int hora, int minuto, int segundo) {
		this.hora = hora;
		this.minuto = minuto;
		this.segundo = segundo;
	}
	
	// getters & setters
	public int getHora() {return this.hora;}
	public int getMinuto() {return this.minuto;}
	public int getSegundo() {return this.segundo;}
	
	public void setHora(int hora) {this.hora=hora;}
	public void setMinuto(int minuto) {this.minuto=minuto;}
	public void setSegundo(int segundo) {this.segundo=segundo;}
	
	// m�todos pr�prios
	public void exibeHorario() {
		System.out.println(String.format("%02d", hora)   +  ":"  +
				           String.format("%02d", minuto) +  ":"  +
				           String.format("%02d", segundo));
	}
	
	public void adiantar(int seg) {
		// converter hor�rio para segundos
		int totseg = hora*3600+minuto*60+segundo;
		// somar os segundos para adiantar
		totseg += seg;
		// pegar os segundos que sobram de um dia
		totseg %= 86400;
		converte(totseg);
	}

	public void atrasar(int seg) {
		// converter hor�rio para segundos
		int totseg = hora*3600+minuto*60+segundo;
		// atrasar os segundos a mais de dias inteiros 
		seg %= 86400;
		// 
		totseg = (totseg - seg + 86400) % 86400;
		converte(totseg);
	}	
	
	private void converte(int totseg) {
		// converter os segundos para hora/minuto/segundo
        hora    = totseg / 3600;
        totseg %= 3600;
        minuto  = totseg / 60;
        totseg %= 60;
		segundo = totseg;
	}
}