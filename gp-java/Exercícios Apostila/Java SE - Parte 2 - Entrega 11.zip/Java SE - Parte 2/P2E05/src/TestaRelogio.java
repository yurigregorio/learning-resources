
public class TestaRelogio {
	
	public static void main(String [] args) {
		Relogio seiko = new Relogio(9,25,10);
		seiko.exibeHorario();
		seiko.atrasar(1);
		seiko.exibeHorario();
	}

}
