package p2e02;

public class Triangulo {
	private double base;
	private double altura;
	public double getBase() {
		return base;
	}
	public void setBase(double base) {
		this.base = base;
	}
	public double getAltura() {
		return altura;
	}
	public void setAltura(double altura) {
		this.altura = altura;
	}
	public Triangulo(double base, double altura) {
		super();
		this.base = base;
		this.altura = altura;
	}
	public Triangulo() {
		
	}
	
	public double getArea() {
		
		return (base*altura)/2;
	}
	
	public double getPerimetro(){
		double baseAoQuadrado = Math.pow(base, 2);
		double alturaAoQuadrado = Math.pow(altura, 2);
		
		return base + altura + Math.pow(baseAoQuadrado+alturaAoQuadrado, 1/2);
	}
}
