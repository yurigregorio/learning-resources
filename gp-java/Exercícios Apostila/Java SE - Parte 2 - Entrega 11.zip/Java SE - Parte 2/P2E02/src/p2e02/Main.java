package p2e02;

public class Main {

	public static void main(String[] args) {
		Circulo c1 = new Circulo(5);
		
		Triangulo t1 = new Triangulo(2,5);
		
		System.out.println("Raio do circulo: " + c1.getRaio());
		System.out.println("area: " + c1.getArea());
		System.out.println("perimetro: "+ c1.getPerimetro());
		
		System.out.println("Altua do triangulo: " + t1.getAltura());
		System.out.println("Base do triangulo: " + t1.getBase());
		System.out.println("area: " + t1.getArea());
		System.out.println("perimetro: "+ t1.getPerimetro());

	}

}
