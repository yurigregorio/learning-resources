package ExerciciosP2;

public class Calculadora {
	//Atributos
	private double memoria = 0;

	//contrutores
	public Calculadora(double memoria) {
		this.memoria = memoria;	
	}
	
	public Calculadora() {
		
	}
	
	//getters & setters

	public double getMemoria() {
		return memoria;
	}

	public void setMemoria(double memoria) {
		this.memoria = memoria;
	}
	
	
	
	//m�todos pr�prios
	public double somar (double valor) {
		this.memoria = this.memoria + valor;
		return memoria;
	}
		
	public double subtrair (double valor) {
		this.memoria = this.memoria - valor;
		return memoria;
	}
	
	public double multiplicar (double valor) {
		this.memoria = this.memoria * valor;
		return memoria;
	}
	
	public double dividir (double valor) {
		this.memoria = this.memoria / valor;
		return memoria;
	}
	
	public void exibeMemoria () {
		System.out.println(getMemoria());
	}
	}
	

