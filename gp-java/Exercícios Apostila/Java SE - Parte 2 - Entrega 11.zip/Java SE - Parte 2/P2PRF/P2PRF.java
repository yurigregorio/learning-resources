package ExerciciosP2;

public class P2PRF {
	public static void main(String[] args) {
		Calculadora x = new Calculadora();
		System.out.println(x.somar(2));
		x.exibeMemoria();
		System.out.println(x.multiplicar(3));
		x.exibeMemoria();
		System.out.println(x.subtrair(2));
		x.exibeMemoria();
		
		
	}
}
