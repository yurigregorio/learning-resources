
public class ContaCorrente {
	
	private int numCC;
	private double saldoCC;
	
	public ContaCorrente() {
		
	}
	
	public ContaCorrente(int numCC, double saldoCC) {
		super();
		this.numCC = numCC;
		this.saldoCC = saldoCC;
	}
	
	public int getNumCC() {
		return numCC;
	}
	public void setNumCC(int numCC) {
		this.numCC = numCC;
	}
	public double getSaldoCC() {
		return saldoCC;
	}
	
	public void depositar(double deposito) {
		saldoCC = saldoCC + deposito;
	}
	
	public void sacar(double saque) {
		saldoCC = saldoCC - saque;
	}

}
