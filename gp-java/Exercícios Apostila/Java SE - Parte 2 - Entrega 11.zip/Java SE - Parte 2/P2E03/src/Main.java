import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
	
		ContaCorrente contaCorrente = new ContaCorrente();
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Digite o n�mero da conta corrente");
		contaCorrente.setNumCC(scanner.nextInt());

		System.out.println("Digite o valor a depositar");
		contaCorrente.depositar(Double.parseDouble(scanner.next()));
		System.out.println("Saldo: R$ " + contaCorrente.getSaldoCC());
		
		System.out.println("Digite o valor a sacar");
		contaCorrente.sacar(Double.parseDouble(scanner.next()));
		System.out.println("Saldo: R$ " + contaCorrente.getSaldoCC());
		
		
	}

}
