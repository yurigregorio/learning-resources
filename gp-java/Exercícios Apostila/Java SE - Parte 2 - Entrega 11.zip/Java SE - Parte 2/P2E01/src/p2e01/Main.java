package p2e01;

public class Main {

	public static void main(String[] args) {
		Funcionario f1 = new Funcionario(123,"Mariana",500);
		Funcionario f2 = new Funcionario();
		f2.setCodFunc(222);
		f2.setNomeFunc("Alejandro");
		f2.setSalarioMensal(700);
		
		System.out.println("cod: " + f1.getCodFunc() + " nome: " + f1.getNomeFunc() + " salario: " + f1.getSalarioMensal());
		System.out.println("cod: " + f2.getCodFunc() + " nome: " + f2.getNomeFunc() + " salario: " + f2.getSalarioMensal());
		
		f1.setAumento(12);
		f2.setAumento(23);
		
		System.out.println("cod: " + f1.getCodFunc() + " nome: " + f1.getNomeFunc() + " salario: " + f1.getSalarioMensal());
		System.out.println("cod: " + f2.getCodFunc() + " nome: " + f2.getNomeFunc() + " salario: " + f2.getSalarioMensal());
	}

}
