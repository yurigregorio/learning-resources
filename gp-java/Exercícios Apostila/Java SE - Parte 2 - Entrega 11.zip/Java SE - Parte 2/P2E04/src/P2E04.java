import java.util.Scanner;

public class P2E04 {

	public static void main(String[] args) {
				
		AlunoDisciplina alunoDisciplina = new AlunoDisciplina();
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Digite o Id do aluno:");
		alunoDisciplina.setIdAluno(scanner.nextInt());
		System.out.println("Digite o Id da disciplina:");
		alunoDisciplina.setIdDisciplina(scanner.nextInt());
		System.out.println("Digite a nota A:");
		alunoDisciplina.setNotaB1(Double.parseDouble(scanner.next()));
		System.out.println("Digite a nota B:");
		alunoDisciplina.setNotaB2(Double.parseDouble(scanner.next()));
	
		System.out.println("Media Aritm�tica: " + alunoDisciplina.mediaAritimetica());
		System.out.println("Media Ponderada: " + alunoDisciplina.mediaPonderada());
	}

}
