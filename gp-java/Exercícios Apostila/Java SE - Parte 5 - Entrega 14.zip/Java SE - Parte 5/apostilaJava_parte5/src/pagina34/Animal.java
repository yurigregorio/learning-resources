package pagina34;

public abstract class Animal implements Som {
	protected int idade;
	protected double peso;
	protected String especie;
	protected String cor;
	
	public Animal(int idade, double peso, String especie, String cor) {
		super();
		this.idade = idade;
		this.peso = peso;
		this.especie = especie;
		this.cor = cor;
	}
	
	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}
}
