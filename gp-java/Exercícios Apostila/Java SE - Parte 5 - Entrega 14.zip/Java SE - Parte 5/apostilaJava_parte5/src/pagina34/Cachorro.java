package pagina34;

public class Cachorro extends Animal {
	public Cachorro(int idade, double peso, String especie, String cor) {
		super(idade, peso, especie, cor);
	}
	
	@Override
	public void som() {
		System.out.println("Au AU aU AU");		
	}
}
