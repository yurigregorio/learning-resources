package pagina34;

public class FazendaFeliz {
	public static void main(String[] args) {
		Cachorro rex = new Cachorro(10, 35.4, "Cachorro", "Caramelo");
		Gato felix = new Gato(5, 5.4, "Gato", "Pardo");
		Galinha caipira = new Galinha(3, 2.4, "Galinha", "Preta");
		Vaca mimosa = new Vaca(16, 120.21, "Vaca", "Cor-sim-cor-n�o");
		
		rex.som();
		felix.som();
		caipira.som();
		mimosa.som();
	}
}
