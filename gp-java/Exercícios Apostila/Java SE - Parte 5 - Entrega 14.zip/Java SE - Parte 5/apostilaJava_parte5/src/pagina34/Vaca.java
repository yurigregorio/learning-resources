package pagina34;

public class Vaca extends Animal {
	public Vaca(int idade, double peso, String especie, String cor) {
		super(idade, peso, especie, cor);
	}

	public void som() {
		System.out.println("Muuuuuuu");
	}
}
