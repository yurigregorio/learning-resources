package pagina34;

public interface Som {
	public void som();
}
