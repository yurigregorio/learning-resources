package pagina34;

public class Gato extends Animal {
	public Gato(int idade, double peso, String especie, String cor) {
		super(idade, peso, especie, cor);
	}

	@Override
	public void som() {
		System.out.println("Miauuuuuuuuuuu");
	}
}
