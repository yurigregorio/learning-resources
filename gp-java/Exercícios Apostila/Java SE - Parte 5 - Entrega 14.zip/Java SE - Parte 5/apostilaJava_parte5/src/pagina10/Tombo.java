package pagina10;

public class Tombo {
	private Integer numeroTombo;

	public Integer getNumeroTombo() {
		return numeroTombo;
	}

	public void setNumeroTombo(Integer numeroTombo) {
		this.numeroTombo = numeroTombo;
	}
}
