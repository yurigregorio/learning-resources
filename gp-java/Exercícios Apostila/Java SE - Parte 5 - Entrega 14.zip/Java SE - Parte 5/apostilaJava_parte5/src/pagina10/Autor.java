package pagina10;

public class Autor {
	private String autores;

	public String getAutores() {
		return autores;
	}

	public void setAutores(String autores) {
		this.autores = autores;
	}	
}
