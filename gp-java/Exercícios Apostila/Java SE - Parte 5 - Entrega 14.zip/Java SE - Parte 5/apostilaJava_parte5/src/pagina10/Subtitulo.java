package pagina10;

public class Subtitulo {
	private String subtitulo;

	public String getSubtitulo() {
		return subtitulo;
	}

	public void setSubtitulo(String subtitulo) {
		this.subtitulo = subtitulo;
	}
}
