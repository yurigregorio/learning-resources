package pagina10;

public class Livro {
	private Assunto assunto;
	private Autor autor;
	private Exemplar exemplar;
	private ISBN isbn;
	private Titulo titulo;
	private Subtitulo subtitulo;
	private Tombo tombo;
	
	public Assunto getAssunto() {
		return assunto;
	}
	
	public void setAssunto(Assunto assunto) {
		this.assunto = assunto;
	}
	
	public Autor getAutor() {
		return autor;
	}
	
	public void setAutor(Autor autor) {
		this.autor = autor;
	}
	
	public Exemplar getExemplar() {
		return exemplar;
	}
	
	public void setExemplar(Exemplar exemplar) {
		this.exemplar = exemplar;
	}
	
	public ISBN getIsbn() {
		return isbn;
	}
	
	public void setIsbn(ISBN isbn) {
		this.isbn = isbn;
	}
	
	public Titulo getTitulo() {
		return titulo;
	}
	
	public void setTitulo(Titulo titulo) {
		this.titulo = titulo;
	}
	
	public Subtitulo getSubtitulo() {
		return subtitulo;
	}
	
	public void setSubtitulo(Subtitulo subtitulo) {
		this.subtitulo = subtitulo;
	}
	
	public Tombo getTombo() {
		return tombo;
	}
	
	public void setTombo(Tombo tombo) {
		this.tombo = tombo;
	}	
}
