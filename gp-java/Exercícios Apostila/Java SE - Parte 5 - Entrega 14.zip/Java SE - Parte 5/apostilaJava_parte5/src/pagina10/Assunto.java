package pagina10;

public class Assunto {
	private String assuntos;

	public String getAssuntos() {
		return assuntos;
	}

	public void setAssuntos(String assuntos) {
		this.assuntos = assuntos;
	}	
}
