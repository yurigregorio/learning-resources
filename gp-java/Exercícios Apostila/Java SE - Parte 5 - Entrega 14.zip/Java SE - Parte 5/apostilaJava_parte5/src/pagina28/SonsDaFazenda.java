package pagina28;

public class SonsDaFazenda extends Animal {
	public SonsDaFazenda(int idade, double peso, String especie, String cor) {
		super(idade, peso, especie, cor);
	}
	
	public static void sonsDaFazenda(Animal a) {
		a.som();
	}

	@Override
	public void som() {
		// TODO Auto-generated method stub
		
	}
}
