package pagina28;

public class Cachorro extends Animal {
	public Cachorro(int idade, double peso, String especie, String cor) {
		super(idade, peso, especie, cor);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void som() {
		System.out.println("Au Au");
	}
}
