package pagina28;

public class Galinha extends Animal {
	public Galinha(int idade, double peso, String especie, String cor) {
		super(idade, peso, especie, cor);
	}

	@Override
	public void som() {
		System.out.println("Cocoric�");		
	}
}
