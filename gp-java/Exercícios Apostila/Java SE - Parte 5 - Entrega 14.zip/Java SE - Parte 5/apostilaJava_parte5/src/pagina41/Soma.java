package pagina41;

public class Soma extends OperacaoMatematica {
	public double calcular(double x, double y) {
		return x + y;
	}
}
