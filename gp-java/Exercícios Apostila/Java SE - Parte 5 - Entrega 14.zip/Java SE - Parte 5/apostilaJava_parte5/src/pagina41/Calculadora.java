package pagina41;

public class Calculadora {
	public static void main(String[] args) {
		Contas.mostrarCalculo(new Soma(), 7, 5);
		Contas.mostrarCalculo(new Subtracao(), 7, 5);
		Contas.mostrarCalculo(new Divisao(), 7, 5);
		Contas.mostrarCalculo(new Multiplicacao(), 7, 5);
		Contas.mostrarCalculo(new Resto(), 7, 5);
	}
}
