package pagina41;

public abstract class OperacaoMatematica {
	public abstract double calcular(double x, double y);
}
