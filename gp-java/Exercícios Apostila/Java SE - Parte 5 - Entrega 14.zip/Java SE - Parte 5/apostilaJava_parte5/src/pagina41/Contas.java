package pagina41;

public class Contas {
	public static void mostrarCalculo
			(OperacaoMatematica operacao, double x, double y) {
		System.out.println("O resultado �: " + operacao.calcular(x, y));
	}
}
