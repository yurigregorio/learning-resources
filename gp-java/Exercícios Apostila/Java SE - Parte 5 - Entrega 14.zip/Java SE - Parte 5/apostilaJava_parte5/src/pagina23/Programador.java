package pagina23;

public class Programador extends Funcionario {
	public Programador(int idFunc, String nomeFunc) {
		super(idFunc, nomeFunc);
		// TODO Auto-generated constructor stub
	}

	private String setor;
	private String linguagem;
	
	public Programador(int idFunc, String nomeFunc, String setor, String linguagem) {
		super(idFunc, nomeFunc);
		this.setor = setor;
		this.linguagem = linguagem;
	}

	@Override
	public void trabalhar() {
		System.out.println("O programador " + nomeFunc + " trabalha no setor " + setor 
				+ " desenvolvendo software na linguagem " + linguagem);
	}
}
