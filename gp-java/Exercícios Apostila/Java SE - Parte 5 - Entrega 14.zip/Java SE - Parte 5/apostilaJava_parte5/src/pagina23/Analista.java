package pagina23;

public class Analista extends Funcionario {
	public Analista(int idFunc, String nomeFunc) {
		super(idFunc, nomeFunc);
		// TODO Auto-generated constructor stub
	}

	private String sistema;

	public Analista(int idFunc, String nomeFunc, String sistema) {
		super(idFunc, nomeFunc);
		this.sistema = sistema;
	}

	@Override
	public void trabalhar() {
		System.out.println("O analista " + nomeFunc + " desenvolve software para o sistema " + sistema);		
	}
}
