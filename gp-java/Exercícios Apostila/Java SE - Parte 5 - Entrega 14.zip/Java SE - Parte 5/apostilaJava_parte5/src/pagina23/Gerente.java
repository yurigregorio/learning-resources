package pagina23;

public class Gerente extends Funcionario {
	public Gerente(int idFunc, String nomeFunc) {
		super(idFunc, nomeFunc);
		// TODO Auto-generated constructor stub
	}

	private String setor;
	private int qtdProgramadores;
	private int qtdAnalistas;
	
	public Gerente(int idFunc, String nomeFunc, String setor, int qtdProgramadores, int qtdAnalistas) {
		super(idFunc, nomeFunc);
		this.setor = setor;
		this.qtdProgramadores = qtdProgramadores;
		this.qtdAnalistas = qtdAnalistas;
	}

	@Override
	public void trabalhar() {
		System.out.println("O gerente " + nomeFunc + " gerencia o setor " + setor + 
				" com " + qtdAnalistas + " analistas e " + qtdProgramadores + 
				" programadores.");
	}
}
