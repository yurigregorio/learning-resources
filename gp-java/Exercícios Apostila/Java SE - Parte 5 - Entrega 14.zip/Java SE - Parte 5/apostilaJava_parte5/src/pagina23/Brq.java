package pagina23;

public class Brq {
	public static void main(String[] args) {
		Programador p1 = new Programador(1, "Jo�o", "Santander", "Java");
		Programador p2 = new Programador(2, "Marcelo", "Santander", "COBOL");
		Analista a1 = new Analista(3, "Carlos", "Gerenciador de Tarefas");
		Gerente g1 = new Gerente(4, "Thales", "Santadender", 2, 1);
		
		p1.trabalhar();
		p2.trabalhar();
		a1.trabalhar();
		g1.trabalhar();
	}
}
