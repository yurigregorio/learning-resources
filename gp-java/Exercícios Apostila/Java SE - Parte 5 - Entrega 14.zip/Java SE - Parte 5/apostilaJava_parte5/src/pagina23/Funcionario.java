package pagina23;

public abstract class Funcionario {
	protected int idFunc;
	protected String nomeFunc;
	
	public abstract void trabalhar();

	public Funcionario(int idFunc, String nomeFunc) {
		super();
		this.idFunc = idFunc;
		this.nomeFunc = nomeFunc;
	}

	public int getIdFunc() {
		return idFunc;
	}

	public void setIdFunc(int idFunc) {
		this.idFunc = idFunc;
	}

	public String getNomeFunc() {
		return nomeFunc;
	}

	public void setNomeFunc(String nomeFunc) {
		this.nomeFunc = nomeFunc;
	}
}
