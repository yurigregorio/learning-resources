package pagina43;

public class Main {
	public static void main(String[] args) {
		Cd cd1 = new Cd(21, 21.02, "Metallica", 20);
		Cd cd2 = new Cd();
		Dvd dvd1 = new Dvd();
		
		cd1.printDados();
	}
}
