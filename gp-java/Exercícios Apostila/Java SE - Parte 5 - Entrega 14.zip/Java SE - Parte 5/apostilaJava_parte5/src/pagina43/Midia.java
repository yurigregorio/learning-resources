package pagina43;

public class Midia {
	protected int codigo;
	protected double preco;
	protected String nome;
	
	public Midia(int codigo, double preco, String nome) {
		super();
		this.codigo = codigo;
		this.preco = preco;
		this.nome = nome;
	}
	
	public Midia() {
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getTipo() {
		return "M�dia";
	}
	
	public String getDetalhe() {
		return "C�digo: " + codigo + ", pre�o: R$: " 
				+ preco + ", nome: " +nome;
	}
	
	public void printDados() {
		System.out.println(getTipo() + "\n"+ getDetalhe());
	}
	
	public void inserirDados(int codigo, double preco, String nome) {
		setCodigo(codigo);
		setPreco(preco);
		setNome(nome);
	}
}
