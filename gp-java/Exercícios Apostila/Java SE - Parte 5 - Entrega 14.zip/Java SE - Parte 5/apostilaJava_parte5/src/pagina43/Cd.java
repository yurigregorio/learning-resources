package pagina43;

public class Cd extends Midia {
	private int nMusicas;

	public Cd(int codigo, double preco, String nome, int nMusicas) {
		super(codigo, preco, nome);
		this.nMusicas = nMusicas;
	}
	
	public Cd() {
	}

	public int getnMusicas() {
		return nMusicas;
	}

	public void setnMusicas(int nMusicas) {
		this.nMusicas = nMusicas;
	}
	
	public String getTipo() {
		return "CD";
	}
	
	public String getDetalhe() {
		return "M�sicas: " + nMusicas;
	}
	
	public void inserirDados(int nMusicas) {
		setnMusicas(nMusicas);
	}
}
