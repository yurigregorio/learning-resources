package pagina43;

public class Dvd extends Midia {
	private int nFaixas;

	public Dvd(int codigo, double preco, String nome, int nFaixas) {
		super(codigo, preco, nome);
		this.nFaixas = nFaixas;
	}
	
	public Dvd() {
	}

	public int getnFaixas() {
		return nFaixas;
	}

	public void setnFaixas(int nFaixas) {
		this.nFaixas = nFaixas;
	}
	
	public String getTipo() {
		return "DVD";
	}
	
	public String getDetalhes() {
		return "Faixas: " + nFaixas;
	}
	
	public void inserirDados() {
		
	}
}
