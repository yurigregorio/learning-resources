package pagina46;

public class FabricaLampada implements Lampada {
	public String tipo;
	public int escolha;
	
	public FabricaLampada(String tipo, Integer escolha) {
		this.tipo = tipo;
		this.escolha = escolha;
	}
	
	public FabricaLampada() {
	}
	
	public class Incandescente {
		private String tipo;
		
		public Incandescente(String tipo) {
			this.tipo = tipo;
		}

		public String getTipo() {
			return tipo;
		}

		public void setTipo(String tipo) {
			this.tipo = tipo;
		}
	}	
	
	public class Fluorescente {
		private String tipo;

		public Fluorescente(String tipo) {
			this.tipo = tipo;
		}

		public String getTipo() {
			return tipo;
		}

		public void setTipo(String tipo) {
			this.tipo = tipo;
		}
	}		
	
	public Object construir(int escolha) {		
		if (escolha == 2) {
			Fluorescente lamp =  new Fluorescente("Fluorescente");
			System.out.println("L�mpada " + lamp.tipo + " criada!");
			return lamp;
		} else {
			Incandescente lamp = new Incandescente("Incandescente");
			System.out.println("L�mpada " + lamp.tipo + " criada!");
			return lamp;
		} 
	}

	@Override
	public void ligar() {
		System.out.println("L�mpada Ligada!");	
	}

	@Override
	public void desligar() {
		System.out.println("L�mpada Desligada!");			
	}
}
