package pagina46;

import java.util.Scanner;

public class ProgramP5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		FabricaLampada fabrica = new FabricaLampada();
		
		System.out.println("Qual l�mpada voc� deseja construir?");
		System.out.println("1 - Incandescente \n2 - Fluorescente");
		int escolha = sc.nextInt();
		if(escolha == 1 || escolha == 2) {
			fabrica.construir(escolha);
		} else {
			System.out.println("Valor inv�lido! Insira 1 ou 2");
		}
		System.out.println();
		
		System.out.print("Digite 1 para ligar e 2 para desligar: ");
		escolha = sc.nextInt();
		if(escolha == 1) {
			fabrica.ligar();
		} else if(escolha == 2) {
			fabrica.desligar();
		} else {
			System.out.println("Valor inv�lido! Insira 1 ou 2");
		}
		
		sc.close();
	}
}
