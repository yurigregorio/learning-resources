package pagina46;

public interface Lampada {
	public void ligar();
	public void desligar();
}
