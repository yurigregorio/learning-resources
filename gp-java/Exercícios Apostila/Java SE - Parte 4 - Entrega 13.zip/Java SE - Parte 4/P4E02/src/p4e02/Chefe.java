package p4e02;

public class Chefe extends Funcionario {
	protected double contas;
	protected double gastosExtras;
	protected double adicionalChefia;
	public double getContas() {
		return contas;
	}
	public void setContas(double contas) {
		this.contas = contas;
	}
	public double getGastosExtras() {
		return gastosExtras;
	}
	public void setGastosExtras(double gastosExtras) {
		this.gastosExtras = gastosExtras;
	}
	public double getAdicionalChefia() {
		return adicionalChefia;
	}
	public void setAdicionalChefia(double adicionalChefia) {
		this.adicionalChefia = adicionalChefia;
	}
	public Chefe() {
		
	}
	public Chefe(double contas, double gastosExtras, double adicionalChefia,String nome, String rg, double salarioMensal) {
		super(nome,rg,salarioMensal);
		this.contas = contas;
		this.gastosExtras = gastosExtras;
		this.adicionalChefia = adicionalChefia;
	}
	
	public double pagamentoExtra(){
		double total=0;
		total = total + super.pagamento();
		total = total + contas + gastosExtras + adicionalChefia;
		return total;
	}
}
