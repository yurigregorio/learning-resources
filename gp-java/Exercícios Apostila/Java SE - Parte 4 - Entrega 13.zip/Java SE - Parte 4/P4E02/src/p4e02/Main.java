package p4e02;

public class Main {

	public static void main(String[] args) {
		Funcionario func = new Funcionario("Ely","323.432.423-09",330);
		func.aumento(500);
		System.out.println(func.pagamento());
		
		func = new Chefe(300,250,332,"Ever","123-445-654-00",1000);
		func.aumento(700);
		System.out.println(((Chefe) func).pagamentoExtra());
		
		

	}

}
