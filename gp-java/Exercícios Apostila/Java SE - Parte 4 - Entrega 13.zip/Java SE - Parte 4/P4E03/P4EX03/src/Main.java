

public class Main {

	public static void main(String[] args) {
		
			Veiculo v1 = new Veiculo();
			
			v1.acelera(0);
			System.out.println(v1.getVelocidade());
			
			v1.desacelera(0);
			System.out.println(v1.getVelocidade());
		

	}

}
