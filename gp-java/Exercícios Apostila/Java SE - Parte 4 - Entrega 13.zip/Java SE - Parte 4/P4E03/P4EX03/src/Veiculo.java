
public class Veiculo {

	private int velocidade = 0;
	private int velocidadeMax = 100;
	
	public int getVelocidade() {
		return this.velocidade;
	}
	
	public int getVelocidadeMax() {
		return this.velocidadeMax;
	}
	
	public void acelera (int incremento) {
		if (velocidade + incremento > velocidadeMax) {
			if (velocidade == 0 || velocidade > velocidadeMax) {
				throw new ArithmeticException("A velocidade n�o poder ser 0 ou maior que a velocidade m�xima");
			}	
		} else {
			velocidade += incremento;
		}
	}
	
	public void desacelera (int decremento) {
		if (velocidade - decremento < 0) {
			if (velocidade == 0 || velocidade > velocidadeMax) {
				throw new ArithmeticException("A velocidade n�o poder ser 0 ou maior que a velocidade m�xima");
			}	
		} else {
			velocidade -= decremento;
		}
	}
}
