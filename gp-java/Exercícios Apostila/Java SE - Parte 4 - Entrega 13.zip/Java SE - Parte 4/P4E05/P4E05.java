package ExerciciosP4;

import java.util.Scanner;

public class P4E05 {
	public static void main(String[] args) {
		Scanner x = new Scanner (System.in);
		boolean erro = false;

		do {
			try {
				System.out.print("Digite um n�mero inteiro: ");
				int numInteiro = x.nextInt();
				erro = false;
			} 
			catch (Exception e) {
				System.out.println("Este n�o � um inteiro num�rico.");
				erro = true;
				x.nextLine();
			}
			finally {
				if (erro) {
					System.out.println("Tente novamente!");
				} else {
					System.out.println("Obrigado!");
				}
			} 	
			} while (erro);
		
	}
	
}
