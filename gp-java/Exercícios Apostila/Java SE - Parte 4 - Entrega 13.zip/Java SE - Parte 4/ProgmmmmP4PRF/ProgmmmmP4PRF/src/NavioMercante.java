
public class NavioMercante {

}
