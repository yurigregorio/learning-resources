

public class NavioDeGuerra extends Navio {
	protected double blindagem;
	protected double ataque;
	
	public NavioDeGuerra(int numTripulantes, String nome, double blindagem, double ataque) {
		super(numTripulantes, nome);
		this.blindagem = blindagem;
		this.ataque = ataque;
	}

	public double getBlindagem() {
		return blindagem;
	}

	public void setBlindagem(double blindagem) {
		this.blindagem = blindagem;
	}

	public double getAtaque() {
		return ataque;
	}

	public void setAtaque(double ataque) {
		this.ataque = ataque;
	}
	
	public String exibirArmas() {
		poderDeFogo();
		return "O nome do navio � " + nome + " e tem " + numTripulantes + " tripulantes";
	}
	
	public String poderDeFogo() {
		return "O poder de fogo deste navio � de " + this.ataque;
	}
}