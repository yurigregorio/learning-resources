
public class P4E04 {
	
	public static void main(String[] args) {
		System.out.println("Antes de A");
		metodoA();
		System.out.println("Depois de A");
	}
	
	public static void metodoA() {
		System.out.println("Antes de B");
		try {
		   metodoB();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Depois de B");
	}
	
	public static void metodoB() {
		System.out.println("Antes de C");
		metodoC();
		System.out.println("Depois de C");
	}
	
	public static void metodoC() {
		System.out.println("Antes de D");
		metodoD();
		System.out.println("Depois de D");
	}
	
	public static void metodoD() {
		System.out.println("m�todo D antes do c�lculo");
		int x = 10 / 0; 
		System.out.println("m�todo D depois do c�lculo");
	}

}
