public class Produto{
	private String codigo;
	private String descricao;
	
	public int getCodigo() {
		return id;
	}
	public void setCodigo(int id) {
		this.id = id;
		
	public int getDescricao() {
		return id;
	}
	public void setDescricao(int id) {
		this.id = id;
}