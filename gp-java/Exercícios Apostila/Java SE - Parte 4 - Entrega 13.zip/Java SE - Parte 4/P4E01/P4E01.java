package ExerciciosP4;
public class P4E01 {
public static void main(String[] args) {
	Pessoa[] minhaLista = new Pessoa[4];
	
	minhaLista[0] = new Pessoa ("Pessoa Yuri");
	minhaLista[1] = new Funcionario("Pessoa / Funcionario Yuri");
	minhaLista[2] = new Professor ("Pessoa/ Professor/ Funcionario Yuri");
	minhaLista[3] = new Aluno ("Yuri");
	
	for (Pessoa p: minhaLista){
		if (p instanceof Aluno) {
			Aluno novo = (Aluno) p;
			System.out.println("\nAluno");
			System.out.println("Nome: "+ novo.getNome());
			System.out.println("CPF: "+novo.getCpf());
			System.out.println("Data de nascimento: "+novo.getDataNascimento());
			p.tirarCopias();
			
		} else if (p instanceof Funcionario) {
			Funcionario novo = (Funcionario) p;
			System.out.println("\nFuncion�rio");
			System.out.println("Nome: "+ novo.getNome());
			System.out.println("CPF: "+novo.getCpf());
			System.out.println("Data de nascimento: "+novo.getDataNascimento());
			p.tirarCopias();
			
			
			
		} else {
			System.out.println("\nProfessor");
			System.out.println("Nome: "+ p.getNome());
			System.out.println("CPF: "+p.getCpf());
			System.out.println("Data de nascimento: "+p.getDataNascimento());
			p.tirarCopias();
		}
	}
	
}
}

