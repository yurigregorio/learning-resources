package ExerciciosP4;

import java.util.Date;

//superClasse
	public class Pessoa {
	//atributos
		protected String nome;
		protected String cpf;
		protected Date dataNascimento;

	//construtores
	public Pessoa(String nome, String cpf, Date dataNascimento) {
		this.nome = nome;
		this.cpf = cpf;
		this.dataNascimento = dataNascimento;
	}
	public Pessoa(String nome){
		this.nome = nome;
	}
	
//getters and setters
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public Date getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	
//m�todos pr�prios
	public void tirarCopias(){
		int qtd;
		double precoCopia = 0.10;
		System.out.println("Voc� pagar� R$ 0,10 centavos por c�pia.");
		
	}

	
}
	

