package ExerciciosP4;

public class Aluno extends Pessoa{
	
	
	public Aluno(String nome) {
		super(nome);
	}

	private String matricula;

	
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public void tirarCopias(){
		int qtd;
		double precoCopia = 0.07;
		System.out.println("Voc� pagar� R$ 0,07 centavos por c�pia.");
	}
}
