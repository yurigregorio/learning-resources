import java.util.Scanner;

public class MediaFacul {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		double nota1, nota2, media, notaExame;
		String situacao;
		
		System.out.println("informe a primeira nota:");
		nota1 = scan.nextDouble();
		System.out.println("informe a segunda nota:");
		nota2 = scan.nextDouble();
		
		media = (nota1 + nota2) / 2;
		
		if (media < 4) {
			situacao = "reprovado direto";
		}
		else if(media >= 7) {
			situacao = "aprovado direto";
		}
		else {
			System.out.println("Informe a nota do Exame:");
			notaExame = scan.nextDouble();
			media = (media + notaExame) / 2;
		
			if (media >= 5) {
				situacao = "aprovado exame";
			}
			else {
				situacao = "reprovado exame";
			}
		
		}
		
		System.out.println(situacao);
		scan.close();
	}

}
