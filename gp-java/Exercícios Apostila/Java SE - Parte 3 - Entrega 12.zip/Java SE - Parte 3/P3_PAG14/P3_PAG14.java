package ExerciciosP3;
import java.util.Scanner;

public class P3_PAG14 {
	public static void main(String[] args) {
		int QtdAluno = 0;
		double nota1, nota2, media, MediaClasse, soma = 0;
		String acabou = "n";
		Scanner entrada = new Scanner(System.in);
	
		while (acabou.equals("n")) {
			System.out.print("Digite a nota 1: ");
			nota1 = entrada.nextDouble();
			System.out.print("Digite a nota 2: ");
			nota2 = entrada.nextDouble();
			
			media = (nota1 + nota2) / 2;
			soma = soma + media;
			QtdAluno = QtdAluno + 1;
			System.out.print("Acabou? s/n :");
			acabou = entrada.next();
			}
		
		MediaClasse = soma / QtdAluno;
		System.out.printf("A m�dia da classe �: %.1f ", MediaClasse);
		entrada.close();
	}
}