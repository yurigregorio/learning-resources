package p3e04;

public class Main {

	public static void main(String[] args) {
		Cosseno coss1 = new Cosseno(4);
		
		coss1.calcularParcelas();
		coss1.somaParcelas();
		System.out.println("O cosseno �: "+ coss1.getCosseno());

	}

}
