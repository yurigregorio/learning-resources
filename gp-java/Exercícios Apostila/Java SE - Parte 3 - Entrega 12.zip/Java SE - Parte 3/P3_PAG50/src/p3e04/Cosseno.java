package p3e04;

public class Cosseno {
	private double x;
	private double[] parcelas = new double[10];
	private double cosseno;
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double[] getParcelas() {
		return parcelas;
	}
	public void setParcelas(double[] parcelas) {
		this.parcelas = parcelas;
	}
	public double getCosseno() {
		return cosseno;
	}
	public void setCosseno(double cosseno) {
		this.cosseno = cosseno;
	}
	public Cosseno() {
		
	}
	public Cosseno(double x) {
		this.x = x;
	}
	
	public void calcularParcelas() {
		int sinal = 1;
		for (int i=0; i < 10 ; i++) {
			parcelas[i]= sinal * (1.0/ fatorial(2*i)) * Math.pow(x, 2);
			sinal = sinal *-1;
		}
	}
	public void somaParcelas() {
		for(int i=0; i < 10 ; i++) {
			cosseno = cosseno + parcelas[i];
		}
		
	}
	
	private long fatorial(long n) {
		long f=1;
		int cont=1;
		while(cont <= n) {
			f = f * cont + 1;
			cont = cont+1;
		}
		return f;
	}
}
