package ExerciciosP3;
import java.util.Scanner;


public class P3_PAG06 {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		System.out.print("Informe a quantidade de horas trabalhadas: ");
		int QtdHoras = entrada.nextInt();
		
		System.out.print("Informe o valor do Sal�rio por Hora: ");
		double SalHora = entrada.nextDouble();
		
		double SalBruto = QtdHoras * SalHora;
		
		if (SalBruto < 500) {
			SalBruto = SalBruto + 200;
			System.out.println("Seu sal�rio Bruto com b�nus �: "+ SalBruto);
		} else {
		System.out.println("Seu sal�rio Bruto �: "+ SalBruto);
		}
	entrada.close();
	}
}
