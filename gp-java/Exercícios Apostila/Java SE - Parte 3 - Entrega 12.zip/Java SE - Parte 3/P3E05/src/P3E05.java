
public class P3E05 {
	public static void main(String[] args) {
		boolean [] array = { true, true, true,  true, true, true, true, true, true, true, true, true,};
		
		for(int i = 0; i < array.length; i++) {
			if(array.length % 2 != 2) {
				array[i]  = false; 
			}
		}
	}
}
