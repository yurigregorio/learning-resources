package ExerciciosP3;

	public class Aluno{
		//atributos
		private int idAluno;
		private Double[] notas = new Double[4];
		private Integer[] classes = new Integer[12];
		private Integer[] escolas = new Integer[20];
		
	
		//construtores
		public Aluno(int idAluno, Double[] notas) {
			this.idAluno = idAluno;
			this.notas = notas;
		}
		
		public Aluno() {
		}

		//getters and setters
		public int getIdAluno() {
			return idAluno;
		}

		public void setIdAluno(int idAluno) {
			this.idAluno = idAluno;
		}

		public Double[] getNotas() {
			double aux = notas[0];
			for (int i=1;i<=4;i++) {
				if(notas[i]>aux) {
					aux = notas[i];
				}
				System.out.println("A maior nota �: "+aux);
			}
			
			return notas;
		}
		
		public void setNotas(Double notas,int i) {
			this.notas[i] = notas;
		}

		public Integer[] getEscolas() {
			return escolas;
		}

		public void setEscolas(Double escolas, int i) {
			this.notas[i] = escolas;
		}

		public Integer[] getClasses() {
			return classes;
		}

		public void setClasses(Integer classes, int i) {
			this.classes[i] = classes;
		}
		

		//M�TODOS pr�prios
		
		public void maiorNota() {
			getNotas();
		//Modificar os for de acordo com a quest�o - 1/2/3/4
			}
		}
		

	

	

