package ExerciciosP3;



public class P3_PAG43 {
	public static void main(String[] args) {	
		/*
		 A)
		 
		Aluno A01 = new Aluno();
		
		A01.setNotas(10.0, 0);
		A01.setNotas(10.0, 1);
		A01.setNotas(10.0, 2);
		A01.setNotas(10.0, 3);
		
		*/
		
		/*
		 * 
		 * B)
		Aluno[] x = new Aluno[80];
		for (int i=0; i <= 80; i++) {
			x[i].setNotas(10.0, 0);
			x[i].setNotas(10.0, 1);
			x[i].setNotas(10.0, 2);
			x[i].setNotas(10.0, 3);
	}
		*/
		
		/*
		 * 
		 * C)
		 
		Aluno[] x = new Aluno[80];
		for (int a= 0; a <= 12; a++){
			x[a].setClasses(1, a);
			for (int e=0; e <= 80; e++) {
				x[e].setNotas(10.0, 0);
				x[e].setNotas(10.0, 1);
				x[e].setNotas(10.0, 2);
				x[e].setNotas(10.0, 3);
			}
		}
		*/
	
		/*
		 * 
		 * 	D)
		 
		Aluno[] x = new Aluno[80];
		for (int i= 0; i <= 20; i++) {
			x[i].setEscolas(1.0, i);
			for (int a= 0; a <= 12; a++){
				x[a].setClasses(1, a);
				for (int e=0; e <= 80; e++) {
					x[e].setNotas(10.0, 0);
					x[e].setNotas(10.0, 1);
					x[e].setNotas(10.0, 2);
					x[e].setNotas(10.0, 3);
			
				}
			}
		}
		*/	
	}
}
