public class TestaPessoa {
	public static void main(String[] args) {
		Pessoa [] povo = new Pessoa[5];
		
		povo[0]=new Pessoa(1,"Pedro",1.5);
		povo[1]=new Pessoa(2,"Maria",1.6);
		povo[2]=new Pessoa(3,"Jos�" ,1.7);
		povo[3]=new Pessoa(4,"Jo�o" ,1.8);
		povo[4]=new Pessoa(5,"Tiago",1.9);
		
		System.out.println("M�dia de Altura = " + 
		                    Pessoa.mediaAltura(povo));
	}
}