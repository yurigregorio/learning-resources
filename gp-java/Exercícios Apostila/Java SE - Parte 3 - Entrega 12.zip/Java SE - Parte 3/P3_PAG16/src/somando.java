
public class somando {

	public static void main(String[] args) {
			int denominador, numerador;
			double soma = 0;
			numerador = 1;
			
			for(denominador = 1;denominador <= 50; denominador++) {
				soma =+ (numerador/denominador);
				
				numerador++;
			}
			System.out.println(soma);
			
	}

}
