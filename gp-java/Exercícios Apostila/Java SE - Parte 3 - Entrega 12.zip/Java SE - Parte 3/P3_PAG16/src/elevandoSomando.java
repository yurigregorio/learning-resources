
public class elevandoSomando {

	public static void main(String[] args) {
		int denominador, expoente;
		double soma = 0;
		expoente = 1;
		
		for(denominador = 50;denominador > 0; denominador--) {
			soma += ((2^expoente)/denominador);
			
			expoente++;
		}
		System.out.println(soma);
		
	}

}
