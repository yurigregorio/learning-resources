import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		int qtdPessoas = 0;
		double altura = 0;
		double somaAltura = 0;
		
		for (int i = 0; i < 10; i++) {
			System.out.println("Digite a altura");
			altura = Double.parseDouble(scanner.next());
			somaAltura = somaAltura + altura;
			qtdPessoas++;
		}
		
		System.out.println("A m�dia de altura �: " + somaAltura / qtdPessoas);
		
	}

}
