import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;


public class Main {

	public static void main(String[] argss) {
	
		List<Pesquisa> list = new ArrayList<Pesquisa>();
		Scanner scanner = new Scanner(System.in);
		
		int nextPesquisa = 0;
		int seq = 0;	 
		int qtdHomens = 0;
		int qtdMulhesres = 0;
		int qtdRespSim = 0;
		int qtdRespNao = 0;
		
		do {
			seq++;
			Pesquisa pesquisa = new Pesquisa();
			Pesquisa.setSequencia(seq);
			pesquisa.setNumPesquisa(Pesquisa.getSequencia());
			
			System.out.println("Digite o sexo");
			pesquisa.setSexo(scanner.next().charAt(0));
			
			System.out.println("Digite a resposta S/N");
			pesquisa.setResposta(scanner.next().charAt(0));
			
			list.add(pesquisa);
			
			System.out.println("Deseja realizar uma nova pesquisa 1 para Sim 0 para n�o");
			nextPesquisa = scanner.nextInt();
		} while (nextPesquisa != 0);
		
		
		for (Pesquisa pesquisa : list) {
			if (pesquisa.getSexo() == 'M') {
				qtdHomens++;
			}else {
				qtdMulhesres++;
			}
			if (pesquisa.getResposta() == 'S') {
				qtdRespSim++;
			}else {
				qtdRespNao++;
			}
						
		}
		
		System.out.println("Quatidade de Homens: " + qtdHomens);
		System.out.println("Quatidade de Mulheres: " + qtdMulhesres);
		System.out.println("Percentual de respostas 'SIM' " + (qtdRespSim * 100 ) / list.size());
		System.out.println("Percentual de respostas 'N�O' " + (qtdRespNao * 100 ) / list.size());

	}

}
