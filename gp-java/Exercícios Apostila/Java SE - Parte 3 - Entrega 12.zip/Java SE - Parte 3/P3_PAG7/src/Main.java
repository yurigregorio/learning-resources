import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		double n1=0,n2=0;
		String situ;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Entre com a primeira nota: ");
		n1 = Double.parseDouble(sc.nextLine());
		System.out.println("Entre com a segunda nota: ");
		n2 = Double.parseDouble(sc.nextLine());
		
		double m = (n1+n2)/2;
		
		if(m<5) {
			situ = "Reprovado";
		}
		else {
			situ = "Aprovado";
		}
		System.out.println(situ + " com media " + m);
	}

}
