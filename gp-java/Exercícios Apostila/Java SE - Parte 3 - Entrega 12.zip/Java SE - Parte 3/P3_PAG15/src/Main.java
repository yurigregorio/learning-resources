import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		double altura=0,menorAltura=0,contador;
		String nome=null, menorNome = null;
		
		Scanner sc = new Scanner(System.in);
		
		menorAltura = 100;
		contador = 0;
		
		do {
			System.out.println("Entre com o nome: ");
			nome = sc.nextLine();	
			System.out.println("Entre com a altura: ");
			altura = Double.parseDouble(sc.nextLine());
			
			if(altura<menorAltura) {
				menorAltura = altura;
				menorNome= nome;
			}
			contador = contador + 1;
		}while(contador < 2 );
		
		System.out.println("Menor altura: "+menorAltura);
		System.out.println("Nome da pessoa com menor altura: "+menorNome);
	}

}
