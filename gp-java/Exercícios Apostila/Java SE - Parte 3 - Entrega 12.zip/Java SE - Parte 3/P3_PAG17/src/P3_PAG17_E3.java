
public class P3_PAG17_E3 {
	
	public static void main(String[] args) {
		
		double s = 0;
		double n1 = 37;
		double n2 = 38;
		double n3 = 1;
		
		for(int i = 0; i < 37; i++) {
			s = s + ( ( (n1--) * (n2--) ) / n3++);
		}
		
		System.out.println("O valor de S �: " + s);
		
	}

}
