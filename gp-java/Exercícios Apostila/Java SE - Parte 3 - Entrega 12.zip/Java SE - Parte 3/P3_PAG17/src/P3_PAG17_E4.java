
public class P3_PAG17_E4 {
	
public static void main(String[] args) {
		
		double s = 0;
		double n1 = 1;
		
		for(int i = 1; i <= 10; i++) {
			s = s + ( (i) / (i * i) );
		}
		
		System.out.println("O valor de S �: " + s);
		
	}

}
