package ExerciciosP3;

public class Turma {
		//atributos
		private int idTurma;
		private int qtdAlunos;
		private Double[] notas = new Double[50];
		double total = 0;
		Double[] notasAcima;
		
		//construtores
		public Turma() {
		}

		public Turma(int idTurma, int qtdAlunos, Double[] notas) {
			this.idTurma = idTurma;
			this.qtdAlunos = qtdAlunos;
			this.notas = notas;
		}

		//get e set
		public int getIdTurma() {
			return idTurma;
		}

		public void setIdTurma(int idTurma) {
			this.idTurma = idTurma;
		}

		public int getQtdAlunos() {
			return qtdAlunos;
		}

		public void setQtdAlunos(int qtdAlunos) {
			this.qtdAlunos = qtdAlunos;
		}

		public Double[] getNotas() {
			for (int i = 1; i < notas.length; i++) { 
				if(notas[i] == null) {
					break;
				}
			//System.out.println(notas[i]);
				total = total + notas[i];
			}
			return notas;
		}

		public void setNotas(Double notas,int i) {
			this.notas[i] = notas;
		}
		
		//m�todosPr�prios
		public void mediaTurma() {
			double media;
			media = total / getQtdAlunos();
			System.out.println("A m�dia da sala �: "+ media);		
			notasAcima = getNotas();
			System.out.println("=================================================\nNotas iguais ou acima da m�dia: ");
			for (int i = 1; i < getQtdAlunos(); i++) {
				if (notasAcima[i] >= media) {
					System.out.println(notasAcima[i]);
				}
			}
		}
}
