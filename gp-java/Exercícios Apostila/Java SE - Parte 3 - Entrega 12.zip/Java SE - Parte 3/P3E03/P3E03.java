package ExerciciosP3;

import java.util.Scanner;

public class P3E03 {
	public static void main(String[] args) {
		

	Scanner x = new Scanner(System.in);
	Turma t01 = new Turma();

	
	System.out.print("Quantidade de alunos: ");
	t01.setQtdAlunos(x.nextInt());
	System.out.println("=================================================");
	//Double notas;
	
	Double notas;

	for(int i=1; i<=t01.getQtdAlunos(); i++) {
		System.out.print("Informe a nota do "+i+"� aluno: ");
		notas = x.nextDouble();
		t01.setNotas(notas, i);	
	}
	
	t01.getNotas();
	System.out.println("=================================================");
	t01.mediaTurma();
	x.close();
}


	}   

