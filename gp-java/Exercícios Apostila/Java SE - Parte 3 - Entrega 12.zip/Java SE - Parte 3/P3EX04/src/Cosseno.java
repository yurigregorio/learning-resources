public class Cosseno {
	// atributos
	private double x;
	private double parcelas [];
	private double cosseno;
	
	// construtores	
	public Cosseno(double x) {
		this.x = x;
		this.parcelas = new double[10];
	}
    public Cosseno(){
    	this.x = 0.0;
		this.parcelas = new double[10];
    }
    
	// getters & setters
	public double getX() {
		return x;
	}
	public double[] getParcelas() {
		return parcelas;
	}
	public double getCosseno() {
		return cosseno;
	}
	public void setX(double x) {
		this.x = x;
	}
	public void setParcelas(double[] parcelas) {
		this.parcelas = parcelas;
	}
	public void setCosseno(double cosseno) {
		this.cosseno = cosseno;
	}; 	

	// m�todos pr�prios
	public void calculaParcelas() {
		for(int i=0; i<parcelas.length; i++) {
			parcelas[i]=  Math.pow(-1, i) * 
					      1.0 / fatorial(2*i) * 
					      Math.pow(x, 2*i);
			System.out.println("Parcela["+i+"]="+parcelas[i]);
		}
	}

	private long fatorial(long n) {
		long f=1;
		int  cont=1;
		while (cont <= n ) f *= cont++;
		return f;		
	}
	
	public void somaParcelas() {
		for(double bacia : parcelas)
			cosseno += bacia;
	}
}