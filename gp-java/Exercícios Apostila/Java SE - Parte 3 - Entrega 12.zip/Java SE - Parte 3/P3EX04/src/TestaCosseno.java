public class TestaCosseno {
	public static void main(String [] args) {
		Cosseno c = new Cosseno();
		c.setX(1);
		c.calculaParcelas();
		c.somaParcelas();
		System.out.println("Cosseno de 1 = " + c.getCosseno());
		System.out.println("Cosseno de 1 = " + Math.cos(1));
	}
}