package ExerciciosP1;

import java.util.Scanner;

public class P1PRF {
	public static void main(String[] args) {
		int a, b, c, d, e, f, g, h, i, j, k, L, DIA, MES, ANO;
			Scanner entrada = new Scanner(System.in);
			System.out.println("Digite o ano: ");
			ANO = entrada.nextInt();
		
			a = ANO % 19;
			b = ANO / 100;
			c = ANO % 100;
			d = b / 4;
			e = b % 4;
			f = (b + 8) / 25;
			g = (b - f + 1) / 3;
			h = (19 * a + b - d - g + 15) % 30;
			i = c / 4;
			j = c % 4;
			k = (32 + 2 * e + 2 * i - h - j) % 7;
			L = (a + 11 * h + 22 * k) / 451;
			MES = (h + k - 7 * L + 114) / 31;
			DIA = ((h + k - 7 * L + 114) % 31) + 1;
			
			System.out.printf("A p�scoa desse ano vai cair na data: " + DIA + "/" + MES + "/" + ANO);
	}
}
