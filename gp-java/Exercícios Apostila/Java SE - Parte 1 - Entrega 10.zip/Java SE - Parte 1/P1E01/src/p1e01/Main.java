package p1e01;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		double m=0,h=0,t=0,cavalos=0;
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("passe a massa em kg:");
			m = Double.parseDouble(sc.nextLine());
			
			System.out.println("passe a altura em metros:");
			h = Double.parseDouble(sc.nextLine());
			
			System.out.println("passe a tempo em segundos:");
			t = Double.parseDouble(sc.nextLine());
		}
		
		cavalos = (((m*h)/t)/ 745.6999);
		
		System.out.println("numeros de cavalos necessarios: " + cavalos);
		

	}

}
