import java.util.Scanner;

public class Temperatura {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		double C, F, K, Ra, Re;
		System.out.println("Informe a temperatura:");
		C = scan.nextDouble();
		
		F = C * 1.8 + 32;
		System.out.println(F);
		
		K = C * 273.15;
		System.out.println(K);
		
		Ra = C * 1.8 + 32 + 459.67;
		System.out.println(Ra);
		
		Re = C * 0.8;
		System.out.println(Re);
		
		scan.close();
		
		
		
	}

}
