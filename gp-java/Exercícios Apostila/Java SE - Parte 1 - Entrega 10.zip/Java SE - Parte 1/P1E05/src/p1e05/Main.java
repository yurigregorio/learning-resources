package p1e05;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		double DP=0,DG=0,PP=0,PM=0,PG=0,QTDLITROS;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("digite o diametro pequeno:");
		DP = Double.parseDouble(sc.nextLine());
		
		System.out.println("digite o diametro grande:");
		DG = Double.parseDouble(sc.nextLine());
		
		System.out.println("digite o profundidade pequena:");
		PP = Double.parseDouble(sc.nextLine());
		
		System.out.println("digite o profundidade media:");
		PM = Double.parseDouble(sc.nextLine());
		
		System.out.println("digite o profundidade grande:");
		PG = Double.parseDouble(sc.nextLine());
		
		PM = (PP+PG)/2;
		QTDLITROS = DG*DP*PM*785;
		
		System.out.println("quantidade de litros �: " + QTDLITROS);
	}

}
