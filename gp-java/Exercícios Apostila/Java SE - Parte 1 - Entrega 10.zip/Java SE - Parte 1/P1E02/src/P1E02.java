import java.util.Scanner;

public class P1E02 {

	public static void main(String[] args) {
		
		double cotacao;
		double reais;
		int q1;
		int q2;
		int q3;
		int q4;
		int q5;
		int q6;

		Scanner lerTecladoScanner = new Scanner(System.in);

		
		System.out.println("Informe o valor da cota��o do Dolar");
		cotacao = Double.parseDouble(lerTecladoScanner.next());
		System.out.println("Informe a quantidade de moedas de:");
		System.out.println("$1");
		q1 = lerTecladoScanner.nextInt();
		System.out.println("50�");
		q2 = lerTecladoScanner.nextInt();
		System.out.println("25�");
		q3 = lerTecladoScanner.nextInt();
		System.out.println("10�");
		q4 = lerTecladoScanner.nextInt();
		System.out.println("5�");
		q5 = lerTecladoScanner.nextInt();
		System.out.println("1�");
		q6 = lerTecladoScanner.nextInt();
		
		reais = (q1 + (0.5 * q2) + (0.25 * q3) + (0.10 * q4) + (0.05 * q5) + (0.01 * q6)) * cotacao;
			
		System.out.println("O valor em reais �: R$ " + reais);
		

	}

}
