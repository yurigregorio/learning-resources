import java.util.Scanner;

public class P1E06 {

	public static void main(String[] args) {
		
		double raio;
		double area;
		double perimetro;
		
		Scanner lerTecladoScanner = new Scanner(System.in);
		
		System.out.println("Digite o raio em metros:");
		raio = Double.parseDouble(lerTecladoScanner.next());
		
		System.out.println("O perimetro do circulo � " + 2 * 3.14159 * raio + " metros");
		System.out.println("A �rea do circulo � de " + 3.14159 * raio + " metros");
		

	}

}
