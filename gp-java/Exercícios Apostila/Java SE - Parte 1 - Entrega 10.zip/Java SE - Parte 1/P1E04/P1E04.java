package ExerciciosP1;
import java.util.Scanner;

public class P1E04 {
	public static void main(String[] args) {
		Scanner x = new Scanner(System.in);
		System.out.print("Hora: ");
		int Hora = x.nextInt();
		System.out.print("Minuto: ");
		int Minuto = x.nextInt();
		System.out.print("Segundo: ");
		int Segundos = x.nextInt();
		x.close();
		
		int SegundosPassados = (Hora * 3600) + (Minuto * 60) + Segundos; // Depois das 00:00:00
		int SegundosRestantes = 86400 - SegundosPassados; // at� as 00:00:00
		
		System.out.printf("J� se passou "+ SegundosPassados + " segundos, desde o hor�rio 00:00:00\n");
		System.out.printf("Faltam "+ SegundosRestantes + " segundos, para o hor�rio 00:00:00");
	}
}
